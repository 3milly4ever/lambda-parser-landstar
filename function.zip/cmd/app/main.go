package main


func main(){
	log.InitLogger()
}